package android.util;
public final class Base64 {
  public static final int DEFAULT = 0, NO_WRAP = 2;
  public static String encodeToString(byte[] value, int flags) { return java.util.Base64.getEncoder().encodeToString(value); }
  public static String encodeToString(byte[] value, int offset, int length, int flags) {
    return encodeToString(java.util.Arrays.copyOfRange(value, offset, offset + length), flags);
  }
  public static byte[] decode(String value, int flags) { return java.util.Base64.getDecoder().decode(value); }
}
